#include <stdio.h>
#include <math.h>

void arm_strong(int a);

int main() {
    int a;
    printf("Enter a number for Armstrong: ");
    scanf("%d", &a);
    arm_strong(a);
    return 0;
}

void arm_strong(int a) {
    int sum = 0, temp, digit = 0, rem;

    temp = a;

    // Count number of digits
    int count = temp;
    while (count != 0) {
        digit++;
        count /= 10;
    }

    temp = a; // reset temp to original
    while (temp != 0) {
        rem = temp % 10;
        sum += pow(rem, digit);
        temp /= 10;
    }

    if (sum == a) {
        printf("It is an Armstrong number\n");
    } else {
        printf("It is not an Armstrong number\n");
    }
}
