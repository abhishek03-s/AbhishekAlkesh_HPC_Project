//fun that will return sum of n num to main
#include<stdio.h>


int fun(int);




int main(){

   int n=5;
   int result = fun(n);
    printf("square of %d num= %d\n",result);
    n=10;

}

void fun(int n){
    int sum=0;
     for(int i=0;i<=n;i++){

     }
    
}