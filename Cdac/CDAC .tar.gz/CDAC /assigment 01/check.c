#include<stdio.h>

int main(){
 printf("hello mic check");
 return 0;
}