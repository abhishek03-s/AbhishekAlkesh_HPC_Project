
// printf("vptr=%u\n", *(int) vptr);
// printf("(vptr+1)=%u\n", *(int*) vptr+1);
